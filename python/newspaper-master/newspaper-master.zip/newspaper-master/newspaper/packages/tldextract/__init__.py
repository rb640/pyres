from .tldextract import extract, TLDExtract

__version__ = "1.2.2"
