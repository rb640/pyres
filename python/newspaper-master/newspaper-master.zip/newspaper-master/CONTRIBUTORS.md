Maintained and authored by:
---------------------------
Lucas Ou-Yang -- lucasyangpersonal@gmail.com

Thanks to the following contributors:
-------------------------------------
- Alex Kessinger - https://github.com/voidfiles
- Oleg Temnov - https://github.com/otemnov
- Matthew Ward - https://github.com/WheresWardy
- Juliano Fischer - https://github.com/julianofischer
- Sandeep Singh - https://github.com/techaddict
- Michael Hood - https://github.com/michaelhood

Newspaper relied on some code of a few other open source projects:
------------------------------------------------------------------
Thanks to all who have contributed to python-goose.
You can find the contributors list here:
https://github.com/grangier/python-goose/graphs/contributors

Thanks to all who have contributed to PyTeaser.
You can find the contributors list here:
https://github.com/xiaoxu193/PyTeaser/graphs/contributors

Thanks to all who have contributed to gravity-goose.
You can find the contributors list here:
https://github.com/GravityLabs/goose/graphs/contributors

Thanks to all who have contributed to python-jieba.
You can find the contributors list here:
https://github.com/fxsjy/jieba/graphs/contributors
