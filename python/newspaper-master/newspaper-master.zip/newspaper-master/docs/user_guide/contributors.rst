.. _contributors:

Contributors
============

Maintained and authored by:
---------------------------
Lucas Ou-Yang -- http://codelucas.com, lucasyangpersonal@gmail.com

Thanks to the following contributors:
-------------------------------------
- Alex Kessinger - https://github.com/voidfiles
- Oleg Temnov - https://github.com/otemnov
- Matthew Ward - https://github.com/WheresWardy  
- Sandeep Singh - https://github.com/techaddict
- Michael Hood - https://github.com/michaelhood
- Juliano Fischer - https://github.com/julianofischer

Newspaper relied on some code of a few other open source projects:
------------------------------------------------------------------
Thanks to all who have contributed to python-goose.
You can find the contributors list here:
https://github.com/grangier/python-goose/graphs/contributors

Thanks to all who have contributed to PyTeaser.
You can find the contributors list here:
https://github.com/xiaoxu193/PyTeaser/graphs/contributors

Thanks to all who have contributed to gravity-goose.
You can find the contributors list here:
https://github.com/GravityLabs/goose/graphs/contributors

Thanks to all who have contributed to jieba.
You can find the contributors list here:
https://github.com/fxsjy/jieba/graphs/contributors

Thanks to all who have contributed to nltk.
You can find the contributors list here:
https://github.com/nltk/nltk/graphs/contributors

Thanks to all who have contributed to lxml.
You can find the contributors list here:
http://lxml.de/credits.html

Thanks to all who have contributed to requests.
You can find the contributors list here:
https://github.com/kennethreitz/requests/graphs/contributors

