# -*- coding: utf-8 -*-

import re
import requests



# text = requests.get('http://rss.ireport.com/feeds/blogs/ireport-blog.rss').text
#
# #url_regex = re.compile("""(?i)\b((?:https?://|www\d{0,3}[.]|[a-z0-9.\-]+[.][a-z]{2,4}/)(?:[^\s()<>]+|\(([^\s()<>]+|(\([^\s()<>]+\)))*\))+(?:\(([^\s()<>]+|(\([^\s()<>]+\)))*\)|[^\s`!()\[\]{};:'".,<>?«»“”‘’]))""")
#
# text = re.sub('<[^<]+?>', '', text)
# #text = re.sub('\r\n', ' ', text)
# print text
# matches = re.findall('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', text)
#
# for m in matches:
#     print m

