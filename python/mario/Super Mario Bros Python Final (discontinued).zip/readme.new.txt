This project has been discontinued for a while now. Recently I decided to come back and work a little bit more on it. I added some new stuff and here is the new result. This will be the final version of the game, I do not intend to release any new stuff in the nearby future.
The game isn't perfect and I belive it has some broken code. Anyway, it should be playable. Thanks for looking!

You'll need Python and Pygame to run this.

Sincerely - HJ.