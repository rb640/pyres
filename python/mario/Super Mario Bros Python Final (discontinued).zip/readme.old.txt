Super Mario Bros. Python release notes:

What is Super Mario Bros. Python?
*********************************
Super Mario Bros. Python is a clone of the original Super Mario Bros 1985 NES.
It is written in Python using pygame. The game is able to run on all systems 
that supports Python2.6++ and pygame.


How to run/install?
*********************************
No installation is required, but you will need some free third-party tools to
run it.

First you will need to download Python2.6 from the Python homepage.
http://python.org/download/

Then you will need a exstra module to Python called pygame. Pygame can be 
downloaded at it's homepage.
http://pygame.org/download.shtml

It is important to download the correct versions! Use the Python2.6 versions 
for this game.


Project page.
*********************************
https://sourceforge.net/projects/supermariobrosp/



*********************************
This file is part of Super Mario Bros. Python.

Super Mario Bros. Python is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Super Mario Bros. Python is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Super Mario Bros. Python.  If not, see <http://www.gnu.org/licenses/>.

                Copyright (C) 2009
